package com.miniproject.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Cart {
	@Id
	@GeneratedValue
	private int cartId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToOne
	@JoinColumn(name="productId")
	private Product product;
	private int quantity;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Cart(int cartId, User user, Product product, int quantity) {
		super();
		this.cartId = cartId;
		this.user = user;
		this.product = product;
		this.quantity = quantity;
	}
	public Cart() {
		
	}
	
	public Cart(int cartId) {
		super();
		this.cartId = cartId;
	}
	@Override
	public String toString() {
		return  cartId + " " + user + " " + product + " " + quantity ;
	}

}
