package com.miniproject.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ContactUs {

	@Id
	@GeneratedValue
	private int contactId;

	private String firstName;

	private String lastName;

	private String eMail;
	
	private String comments;
	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public ContactUs(int contactId, String firstName, String lastName, String eMail, String comments) {
		super();
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.eMail = eMail;
		this.comments = comments;
	}
	public ContactUs() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ContactUs [contactId=" + contactId + ", firstName=" + firstName + ", lastName=" + lastName + ", eMail="
				+ eMail + ", comments=" + comments + "]";
	}
	
	
}
