package com.miniproject.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	@GeneratedValue
	private int productId;
	private String productName;
	private int productOffer;
	private int productPrice;
	private String profilePic;
	public Product(int productId, String productName, int productOffer, int productPrice, String profilePic) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productOffer = productOffer;
		this.productPrice = productPrice;
		this.profilePic = profilePic;
	}
	
	public Product(int productId) {
		super();
		this.productId = productId;
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductOffer() {
		return productOffer;
	}
	public void setProductOffer(int productOffer) {
		this.productOffer = productOffer;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return  productId + " " + productName + " " + productOffer
				+ " " + productPrice + " " + profilePic ;
	}

}
