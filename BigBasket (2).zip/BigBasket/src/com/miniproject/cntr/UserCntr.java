package com.miniproject.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import com.miniproject.dao.UserDao;
import com.miniproject.dto.ContactUs;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;
import com.miniproject.service.ProductService;
import com.miniproject.service.userService;
@Controller
public class UserCntr {
     @Autowired
	private userService uServe;
     
     @Autowired
 	private ProductService userproductService;
     
     @Autowired
  	private UserDao ud;
     @Autowired
     private MailSender mailSender;
     
     @RequestMapping(value="/user_reg_form.htm")
 	public String prepRegForm(ModelMap map) {
 		
		map.put("user", new User());
 		
 		return "User_registration_form";
 	}
 	
 	@RequestMapping(value="/user_reg_submit.htm",method = RequestMethod.POST)
 	public String register(User user) {
 		uServe.reguser(user);
 		return "index";
 	}
 	
 	@RequestMapping(value = "/user_login_submit.htm",method = RequestMethod.POST)
	public String login(User user,ModelMap map, HttpSession session) {
 	
 		boolean b = uServe.loginUser(user);
 		
		if(b) {
			    if(user.getUserEmail().equals("garud@gmail.com") && user.getUserPass().equals("1111")) {
				        session.setAttribute("Getsession", user);
				
				        return "admin_home";
			}
			    else {
			           session.setAttribute("Getsession", user);
			           List<Product> li = userproductService.selectAll();
						map.put("userproductList", li);
						map.put("contact", new ContactUs());
					
			           return "user_home";
			         }
			
		}  else {
			String msg  = "dvrgvfstehd";
			map.put("Errmsg", msg);
			map.put("patient", new User());
			return "index";
		}
	}
 		
 	
 	
 	
 	@RequestMapping(value = "/logout.htm")
	public String logout(HttpSession session, HttpServletResponse response) throws IOException {
		session.invalidate();
		//response.sendRedirect("index.jsp");
		return "index";
	}
 	
 	public static void checkSession(HttpSession hs,HttpServletResponse r) throws IOException {
		Object s = (Object) hs.getAttribute("Getsession");
	
System.out.println(s+"+++++++++++++");
		if(s  == null) {
			//System.out.println(s.getUserId()+""+"ifmadhe");
			System.out.println("ooooo");
			r.sendRedirect("./");	
		}
	}
 	
// 	
// 	 @RequestMapping(value = "/user_msg.htm")
//		public String msgAdd(ContactUs contact,HttpSession session,HttpServletRequest request,ModelMap map,HttpServletResponse r) throws IOException {
// 		System.out.println("------");
// 		 UserCntr.checkSession(session, r);
//  		System.out.println("------"); 	
//	
//			return "redirect:user_msg1.htm";
//		}
 	 
 	 @RequestMapping(value = "/user_msg.htm")
		public String msgAdd1(ContactUs contact,HttpSession session,HttpServletRequest request,ModelMap map,HttpServletResponse r) throws IOException {
		 UserCntr.checkSession(session, r);
	System.out.println(contact);
		ud.insertMsg(contact);
		System.out.println("++++++++++++++++");
	
			return "ContactUs";
		}
 	 
 	 
 	 @RequestMapping(value = "/get_password.htm")
	public String validateAdmin(@RequestParam("userEmail") String userEmail, HttpSession session,ModelMap map) {
 		 
 	boolean b1	= ud.checkMail(userEmail);
 	
 	if(b1) {
 		 
		String pass = ud.validateUser(userEmail);
		System.out.println("pass "+pass);
		if(pass != null) {
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("cdacmumbai3@gmail.com");  
	        message.setTo(userEmail);  
	        message.setSubject("Your password is : ");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
	        return "passSucc";
		}
		else {
			return "ForgetPassword";
		}
		
 	}
 	
 	else {
 		String msg  = "dvrgvfstehd";
		map.put("Errmsg1", msg);
	
		return "ForgetPassword";
 	}
 	
	}
 	 
 	 
 	@RequestMapping(value = "/upload_file.htm", method = RequestMethod.POST)
	public String uploadFile(@RequestParam("file") MultipartFile file,HttpSession session,HttpServletRequest request,ModelMap map) {
		String fileName = "0";

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				fileName = file.getOriginalFilename();
				fileName = fileName.substring(fileName.lastIndexOf("."));
				
				User user = (User)session.getAttribute("Getsession");
				
				fileName = user.getUserId()+fileName;
				
				

				// Creating the directory to store file
				String rootPath = request.getServletContext().getRealPath("/");
				File dir = new File(rootPath + File.separator + "images");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				
				
				String filePath = dir.getAbsolutePath()+ File.separator +fileName;
				
				System.out.println("Server File Location= "+ filePath );
				
				File serverFile = new File(filePath);
				
						
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				
				uServe.uploadImage(fileName, user.getUserId());
				
				user.setProfilePic(fileName);
				

			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
		return "profileUpdate";
	}
 	 
}
