package com.miniproject.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;

import com.miniproject.dao.ProductDao;
import com.miniproject.dto.ContactUs;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;
import com.miniproject.service.ProductService;

@Controller
public class ProductCntr {
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ProductDao productdao;

	 @RequestMapping(value="/add_product_form.htm" )
	 	public String prepRegForm(ModelMap map,HttpSession hs, HttpServletResponse r) throws IOException {
		
			map.put("Product", new Product());
	 		
	 		return "add_products";
	 	}
	 
	 
	 @RequestMapping(value="/add_product_form1.htm" )
	 	public String prepRegForm1(ModelMap map,HttpSession hs, HttpServletResponse r) throws IOException {
		 UserCntr.checkSession(hs, r);
		
	 		
	 		return "redirect:add_product_form.htm";
	 	}
	 
	 
	 
	 
	 
	 @RequestMapping(value = "/product_add.htm",method = RequestMethod.POST)
		public String expenseAdd(Product product,HttpSession session,HttpServletRequest request,ModelMap map) {
		productService.addProduct(product);
		
	
			return "admin_home";
		}
		
	 @RequestMapping(value = "/show_admin_product.list.htm",method = RequestMethod.GET)
		public String allExpenses(ModelMap map,HttpSession session) {
			
			List<Product> li = productService.selectAll();
			map.put("productList", li);
			return "showallAdmin";
		}
	 
	 @RequestMapping(value = "/update_admin_product.list.htm",method = RequestMethod.GET)
		public String updatelist(ModelMap map,HttpSession session) {
		 
			List<Product> li = productService.selectAll();
			map.put("productList", li);
			return "UpdateAdminProduct";
		}
	 
	 @RequestMapping(value = "/update_admin_form.htm",method = RequestMethod.GET)
		public String expenseUpdateForm(@RequestParam int productId,ModelMap map,Product product,HttpSession session) {
		 session.setAttribute("GetProductsession", product);
		 Product pro = productService.findProduct(productId);
			map.put("product", pro);
			
			return "Update_list_form";
		}
	 
	 @RequestMapping(value = "/product_update.htm",method = RequestMethod.POST)
		public String expenseUpdate(Product product,ModelMap map,HttpSession session) {
			System.out.println(((Product)session.getAttribute("GetProductsession")).getProductId());
			int productId = ((Product)session.getAttribute("GetProductsession")).getProductId();
			product.setProductId(productId);
			productService.modifyProduct(product);
				
			List<Product> li = productService.selectAll();
			map.put("productList", li);
			return "UpdateAdminProduct";
		}
	 
	 @RequestMapping(value = "/delete_admin_product.htm",method = RequestMethod.GET)
		public String expenseDelete(@RequestParam int deleteproductId,ModelMap map,HttpSession session) {
			
		 productService.removeProduct(deleteproductId); 
			List<Product> li = productService.selectAll();
			map.put("productList", li);
			return "UpdateAdminProduct";
		}
	 
	 
	 @RequestMapping(value = "/show_admin_complaints.htm",method = RequestMethod.GET)
		public String allcomplatins(ModelMap map,HttpSession session) {
			
			List<ContactUs> li = productdao.selectAllComp();
			map.put("contactList", li);
			return "showallAdmin";
		}
}
