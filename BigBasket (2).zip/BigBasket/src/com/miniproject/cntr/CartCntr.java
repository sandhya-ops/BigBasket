package com.miniproject.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.miniproject.dao.CartDao;
import com.miniproject.dao.UserDao;
import com.miniproject.dto.Cart;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;
import com.miniproject.service.CartServiceDao;
import com.miniproject.service.ProductService;


@Controller
public class CartCntr {

	@Autowired
	private CartServiceDao cartServiceDao;
	
	@Autowired
	private CartDao cartDao;
	
	@Autowired
	private UserDao userDao;
	
	
	@Autowired
	private ProductService productServiceCart;
	
	  @Autowired
	 	private ProductService userproductService;
	     
	 @RequestMapping(value="/add_to_cart.htm") 
	 public  String prepRegForm(@RequestParam int cartproductId,ModelMap map,HttpSession
	  session,Cart cart) throws IOException {
		 System.out.println(" =========");
	
	  map.put("Cart", new Cart());
	 
	  Product pro = productServiceCart.findProduct(cartproductId);
	  
	  
	 User userid = (User)session.getAttribute("Getsession");
	 System.out.println(pro+" =========");
	 System.out.println(userid+" =========");
	 cart.setQuantity(1);
	  cart.setUser(userid); 
	  cart.setProduct(pro);
	  cartServiceDao.addCart(cart); 
	
	  List<Product> li = productServiceCart.selectAll();
	  map.put("userproductList", li);
	  return "user_home";
	  }
	 
	 
	 
	 @RequestMapping(value = "/get_Cart.htm",method = RequestMethod.GET)
		public String allExpenses(ModelMap map,HttpSession session) {
		 
		 int s = ((User) session.getAttribute("Getsession")).getUserId();
			List<Cart> li = cartServiceDao.selectAllCart(s);
			map.put("cartList", li);
			return "Cart";
		}
	 
	 @RequestMapping(value = "/remove_from_cart.htm",method = RequestMethod.GET)
		public String expenseDelete(@RequestParam int cartId, ModelMap map,HttpSession session) {
		
		
		 
		 cartServiceDao.removeCart(cartId); 
		 
		 int s = ((User) session.getAttribute("Getsession")).getUserId();
			List<Cart> li = cartServiceDao.selectAllCart(s);
			map.put("cartList", li);
			return "Cart";
		}
	 
	 
	 @RequestMapping(value = "/user_home.htm",method = RequestMethod.GET)
		public String userhome(ModelMap map,HttpSession session) {
		
		 List<Product> li = userproductService.selectAll();
			map.put("userproductList", li);
        return "user_home";
		}
	 
	 @RequestMapping(value = "/get_profile.htm",method = RequestMethod.GET)
		public String expenseUpdateForm(ModelMap map,User user,HttpSession session) {
		 
		 int s = ((User) session.getAttribute("Getsession")).getUserId();
		User user1 = userDao.selectuser(s);
			map.put("profile", user1);
			
			return "UserProfile";
		}
}
