package com.miniproject.dao;

import java.util.List;

import com.miniproject.dto.Cart;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;

public interface CartDao {
	void insertCart(Cart cart);
	List<Cart> selectAllCart(int cartuserid);
	void deleteCart(int cartid);

}
