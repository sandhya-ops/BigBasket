package com.miniproject.dao;

import com.miniproject.dto.ContactUs;
import com.miniproject.dto.User;

public interface UserDao {

	void addUser(User user);
	boolean checkUser(User user);
	void insertMsg(ContactUs contact);

	User selectuser(int userId);
	String validateUser(String userEmail);
	void uploadImage(String profilePic, int userId);
	boolean checkMail(String mail);
}
