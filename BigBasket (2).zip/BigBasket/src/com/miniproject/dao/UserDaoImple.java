package com.miniproject.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.miniproject.dto.ContactUs;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;


@Repository
public class UserDaoImple implements UserDao {

	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public void addUser(User user) {
		
		ht.execute(new HibernateCallback<Void>() {
			
			@Override
			public Void doInHibernate(Session session) throws HibernateException {

				Transaction tr = session.beginTransaction();
				session.save(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
			} 
		});
	}

	@Override
	public boolean checkUser(User user) {
	
		Boolean b= ht.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {

				Transaction tr = session.beginTransaction();
				Query q= session.createQuery("from User where userEmail = ? and userPass = ?");
				q.setString(0,user.getUserEmail());
				q.setString(1,user.getUserPass());
				List<User> li = q.list();
				System.out.println(li + " " + user.getUserEmail());
				boolean flag = !li.isEmpty();
				if(flag) {
				user.setUserId(li.get(0).getUserId());
				user.setUserName(li.get(0).getUserName());
				user.setProfilePic(li.get(0).getProfilePic());
				}
				tr.commit();
				session.flush();
				session.close();
				return flag;
				
			}
		});
		return b;
	
	}
	
	
	
	@Override
	public void insertMsg(ContactUs contact1) {
		ht.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println(contact1+"______________________");
				session.save(contact1);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

	}
	
	@Override
	public User selectuser(int userId) {
		User user = ht.execute(new HibernateCallback<User>() {

			@Override
			public User doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				User ex = (User)session.get(User.class, userId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return user;
	}
	
	@Override
	public String validateUser(String userEmail) {
		return ht.execute(new HibernateCallback<String>() {
			@Override
			public String doInHibernate(Session s) throws HibernateException {
				Transaction tr = s.beginTransaction();
				Query query2 = s.createQuery("from User where userEmail=?" );
			
				query2.setString(0, userEmail);
				
				List <User>li = query2.list();
		//		System.out.println("(String) li.get(0) "+(String) li.get(0));
				if(!li.isEmpty()) {
					return li.get(0).getUserPass();
				}
				tr.commit();
				s.flush();
				s.close();		
				return null;
			}
		});
	}
	
	
	@Override
	public void uploadImage(String profilePic,int userId) {
		ht.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				User user = (User)session.get(User.class, userId);
				user.setProfilePic(profilePic); 
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}


	
	
	
	@Override
	public boolean checkMail(String mail) {
	
		Boolean b= ht.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {

				Transaction tr = session.beginTransaction();
				Query q= session.createQuery("from User where userEmail = ? ");
				q.setString(0,mail);
			
				List<User> li = q.list();
			
				boolean flag = !li.isEmpty();
				
				tr.commit();
				session.flush();
				session.close();
				return flag;
				
			}
		});
		return b;
	
	}
	
	
	
	
}
