package com.miniproject.dao;

import java.util.List;

import com.miniproject.dto.ContactUs;
import com.miniproject.dto.Product;


public interface ProductDao {
	
	void insertProduct(Product product);
	void deleteProduct(int productId);
	Product selectProduct(int productId);
	void updateProduct(Product product);
	List<Product> selectAll();
	
	void uploadImage(String profilePic,int productId);
	List<ContactUs> selectAllComp();
}
