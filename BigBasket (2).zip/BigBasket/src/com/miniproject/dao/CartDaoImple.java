package com.miniproject.dao;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.miniproject.dto.Cart;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;
@Repository
public class CartDaoImple implements CartDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertCart(Cart cart) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println("************");
				session.save(cart);
				System.out.println("++++++++++++");
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

	}
	
	@Override
	public List<Cart> selectAllCart(int cartuserid) {
		List<Cart> cartList = hibernateTemplate.execute(new HibernateCallback<List<Cart>>() {

			@Override
			public List<Cart> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Cart where userId = ?");
				q.setInteger(0,cartuserid);
				List<Cart> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return cartList;
	}
	
	@Override
	public void deleteCart(int cartid) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				session.delete(new Cart(cartid));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

	}
	


}
