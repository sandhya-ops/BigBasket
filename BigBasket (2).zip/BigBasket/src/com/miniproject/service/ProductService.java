package com.miniproject.service;

import java.util.List;

import com.miniproject.dto.Product;

public interface ProductService {
	void addProduct(Product product);
	void removeProduct(int productId);
	Product findProduct(int productId);
	void modifyProduct(Product product);
	List<Product> selectAll();
	
	void uploadImage(String profilePic,int productId);
}
