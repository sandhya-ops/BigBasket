package com.miniproject.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.miniproject.dao.UserDao;
import com.miniproject.dto.User;
@Service
public class UserServiceImple implements userService {

	@Autowired
	private UserDao uDao;;
	
	@Override
	public void reguser(User user) {
		uDao.addUser(user);
	}

	@Override
	public boolean loginUser(User user) {
		
		return uDao.checkUser(user);
	}
	
	
	@Override
	public void uploadImage(String profilePic, int userId) {
		uDao.uploadImage(profilePic, userId);
	}

}
