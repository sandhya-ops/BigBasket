package com.miniproject.service;

import java.util.List;

import com.miniproject.dto.Cart;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;

public interface CartServiceDao {
	void addCart(Cart cart);
	List<Cart> selectAllCart(int cartuserId);
	void removeCart(int cartId);
}
