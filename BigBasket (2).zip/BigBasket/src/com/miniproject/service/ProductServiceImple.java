package com.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miniproject.dao.ProductDao;
import com.miniproject.dto.Product;
@Service
public class ProductServiceImple implements ProductService {
   @Autowired
	private ProductDao productDao;
	 
	@Override
	public void addProduct(Product product) {
		productDao.insertProduct(product);

	}

	@Override
	public void removeProduct(int productId) {
		productDao.deleteProduct(productId);

	}

	@Override
	public Product findProduct(int productId) {
		return productDao.selectProduct(productId);
	}

	@Override
	public void modifyProduct(Product product) {
		productDao.updateProduct(product);
	}

	@Override
	public List<Product> selectAll() {
		return productDao.selectAll();
	}
	
	@Override
	public void uploadImage(String profilePic, int productId) {
		productDao.uploadImage(profilePic, productId);
	}

}
