package com.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miniproject.dao.CartDao;
import com.miniproject.dao.ProductDao;
import com.miniproject.dto.Cart;
import com.miniproject.dto.Product;
import com.miniproject.dto.User;
@Service
public class CartServiceImple implements CartServiceDao {

	 @Autowired
		private CartDao cartDao;
	
	@Override
	public void addCart(Cart cart) {
		cartDao.insertCart(cart);
	}
	
	
	@Override
	public List<Cart> selectAllCart(int cartuserId) {
		return cartDao.selectAllCart( cartuserId);
	}
	
	@Override
	public void removeCart(int cartId) {
		cartDao.deleteCart(cartId);

	}

}
