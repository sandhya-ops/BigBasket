package com.miniproject.service;

import com.miniproject.dto.User;

public interface userService {
	void reguser(User user);
	boolean loginUser(User user);
	void uploadImage(String profilePic, int userId);
}
